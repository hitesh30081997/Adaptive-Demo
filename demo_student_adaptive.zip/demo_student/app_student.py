"""
app_student.py
Gradio demo for YOUR trained SLU model (from the Code folder), in the same style
as app3.py (NeMo Conformer SLURP demo): record/upload speech, optionally mix in
background noise at a chosen SNR, and see the extracted intent + slots.

It auto-detects which kind of checkpoint you give it:

  A) Sequence-KD student   (train_seq_kd.py  ->  ckpt_seq_kd/best_student.pt)
     HuBERT/WavLM encoder + the teacher's Transformer decoder. Output format is
     identical to the NeMo model:  {'scenario': .., 'action': .., 'entities': [..]}
     Needs the teacher .nemo file (for decoder architecture + tokenizer).

  B) CTC student           (train.py / train_kd.py  ->  ckpt*/best_model.pt)
     HuBERT intent classifier + slot-tagging CTC head. Needs intent_labels.json
     and ctc_vocab.json (or bpe_tokenizer.json) next to the checkpoint.

Optionally the NeMo teacher's prediction is shown next to yours on the same
(noisy) audio, so the audience can compare both models live.

A third model, RoBISLU (code_RoBISLU/train.py -> best_model.pt: WavLM/HuBERT
encoder + attention-pooled intent head + BiLSTM-CTC slot head), runs on the same
audio, and all three results are shown side by side with a comparison table.

"Teach the models" panel: correct a wrong answer, save it, and adapt all three
models to it without forgetting what they already know (see adaptation.py).

Run (from any folder):
    python3 app_student.py
    python3 app_student.py --ckpt /path/to/best_student.pt --teacher_nemo /path/to/model.nemo
"""
import argparse
import importlib.util
import json
import os
import sys
import tempfile
import time
from pathlib import Path

import librosa
import numpy as np
import soundfile as sf
import torch

import gradio as gr

# =========================================================================== #
# EDIT THESE PATHS (or pass them on the command line, see --help)
# =========================================================================== #
CODE_DIR = "/home/common/users/Intern/Hitesh/Speech Intent Classification Demo/My_Model_Demo/Code"                                    # your unzipped Code folder
STUDENT_CKPT = "/home/common/users/Intern/Hitesh/Speech Intent Classification Demo/My_Model_Demo/Code/run_full_200_epochs/best_student.pt"    # your trained model
TEACHER_NEMO = ("/home/common/users/Intern/Hitesh/Speech Intent Classification Demo/My_Model_Demo/Code/"
                "slu_conformer_transformer_large_slurp.nemo")    # same file app3.py uses
NOISE_DIR = "/home/common/users/Intern/Hitesh/Speech Intent Classification Demo/noises"                                 # noises/<class>/<file>.wav

# The checkpoint stores the encoder name used at training time. If that was a local
# folder on another machine (e.g. /home/hp2/models/Wavlm-base-plus), set this to a
# folder that exists here or to the Hugging Face name. Your checkpoint already holds
# all the fine-tuned encoder weights; this is only used to build the architecture.
# None = use the stored name, or pick the matching public model if that path is missing.
HUBERT_NAME_OVERRIDE = "/home/common/Models/Wavlm-base-plus"        # e.g. "microsoft/wavlm-base-plus"

# ---- Third model: RoBISLU (trained with code_RoBISLU/train.py) ----------------
ROBISLU_CODE_DIR = ("/home/common/users/Intern/Hitesh/Speech Intent Classification Demo/"
                    "My_Model_Demo/code_RoBISLU")                  # folder with model.py, vocab.py
ROBISLU_CKPT = ("/home/common/users/Intern/Hitesh/Speech Intent Classification Demo/"
                "My_Model_Demo/code_RoBISLU/ckpt/best_model.pt")   # train.py --output_dir/best_model.pt
ROBISLU_CKPT_DIR = None   # folder with intent_labels.json + ctc_vocab.json; None = folder of ROBISLU_CKPT
# Encoder used to build the architecture (weights come from the checkpoint). The encoder
# type (WavLM/HuBERT/wav2vec2), size, layer fusion and vocab type are detected from the
# checkpoint; if this does not match, a matching public model is used instead.
ROBISLU_HUBERT_NAME = "/home/common/Models/Wavlm-base-plus"
# train.py does not save these two, so they cannot be read from the checkpoint:
ROBISLU_SEMANTIC_LAYER = 8        # only used if trained with --layer_fusion single (train.py default 8)
ROBISLU_FUSION_LAYERS = None      # only if trained with --layer_fusion weighted_sum --fusion_layers "..."
                                  # e.g. "4,6,8,10,12"; None = all layers (train.py default)

# ---- Learning from user corrections (adaptation.py) ---------------------------
ADAPT_STORE = str(Path(__file__).resolve().parent / "adaptation_store")  # corrections, anchors, adapted weights
REPLAY_DIR = None        # folder made by make_replay_set.py (replay.jsonl + audio/); None = anchors only
ADAPT_TOP_LAYERS = 2     # top encoder layers updated per model (the rest stays frozen)
ADAPT_TOLERANCE = 0.02   # max allowed drop of the old score (2 points) before rolling back

# Only used for type-B checkpoints (best_model.pt from train.py / train_kd.py).
# If kd_args.json is next to the checkpoint, these are read from it automatically.
CTC_HUBERT_NAME = "/home/common/Models/Wavlm-base-plus"
CTC_SEMANTIC_LAYER = 10
CTC_LAYER_FUSION = "single"        # "single" | "weighted_sum" (must match training)
CTC_FUSION_LAYERS = None           # e.g. "1,2,3,4,5,6,7,8,9,10,11,12"
CTC_VOCAB_TYPE = "char"            # "char" | "bpe"
# =========================================================================== #

SNR_OPTIONS = [0, 5, 10]  # dB
BEAM_OPTIONS = [1, 4, 8, 32]
TARGET_SR = 16000
AUDIO_EXTS = (".wav", ".flac", ".mp3", ".ogg")


def parse_args():
    p = argparse.ArgumentParser(description="Demo for your trained SLU model")
    p.add_argument("--code_dir", default=CODE_DIR)
    p.add_argument("--ckpt", default=STUDENT_CKPT)
    p.add_argument("--teacher_nemo", default=TEACHER_NEMO)
    p.add_argument("--noise_dir", default=NOISE_DIR)
    p.add_argument("--hubert_name", default=HUBERT_NAME_OVERRIDE,
                   help="Override the encoder name/path stored in the checkpoint")
    p.add_argument("--no_teacher", action="store_true",
                   help="Don't load the NeMo teacher for comparison (type-B checkpoints only)")
    p.add_argument("--robislu_code_dir", default=ROBISLU_CODE_DIR)
    p.add_argument("--robislu_ckpt", default=ROBISLU_CKPT)
    p.add_argument("--robislu_ckpt_dir", default=ROBISLU_CKPT_DIR)
    p.add_argument("--robislu_hubert_name", default=ROBISLU_HUBERT_NAME)
    p.add_argument("--robislu_semantic_layer", type=int, default=ROBISLU_SEMANTIC_LAYER)
    p.add_argument("--robislu_fusion_layers", default=ROBISLU_FUSION_LAYERS)
    p.add_argument("--no_robislu", action="store_true", help="Don't load the RoBISLU model")
    p.add_argument("--adapt_store", default=ADAPT_STORE)
    p.add_argument("--replay_dir", default=REPLAY_DIR)
    p.add_argument("--adapt_top_layers", type=int, default=ADAPT_TOP_LAYERS)
    p.add_argument("--adapt_tolerance", type=float, default=ADAPT_TOLERANCE)
    p.add_argument("--no_adapted", action="store_true",
                   help="Start with the original weights (ignore saved adapted weights)")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--port", type=int, default=6358)
    return p.parse_args()


ARGS = parse_args()
DEVICE = ARGS.device
sys.path.insert(0, str(Path(ARGS.code_dir).resolve()))  # so we can import your modules
sys.path.append(str(Path(__file__).resolve().parent))  # adaptation.py lives next to this file

# Imported after sys.path is set (these come from your Code folder)
from semantics_utils import parse_semantics  # noqa: E402


PUBLIC_ENCODERS = {               # local folder name hint -> Hugging Face model
    "wavlm-base-plus": "microsoft/wavlm-base-plus",
    "wavlm-base": "microsoft/wavlm-base",
    "wavlm-large": "microsoft/wavlm-large",
    "hubert-base": "facebook/hubert-base-ls960",
    "hubert-large": "facebook/hubert-large-ll60k",
    "wav2vec2-base": "facebook/wav2vec2-base",
}


def resolve_encoder_name(stored):
    """Encoder name to build the model with (weights then come from your checkpoint)."""
    if ARGS.hubert_name:
        return ARGS.hubert_name
    looks_local = stored.startswith(("/", ".", "~")) or stored.count("/") > 1
    if not looks_local or os.path.isdir(os.path.expanduser(stored)):
        return stored
    base = os.path.basename(stored.rstrip("/")).lower()
    for hint, hub_name in PUBLIC_ENCODERS.items():   # longest/most specific hints listed first
        if base.startswith(hint):
            print(f"Encoder path {stored!r} not found here -> using {hub_name!r} for the architecture "
                  "(your fine-tuned weights are loaded from the checkpoint)")
            return hub_name
    raise SystemExit(f"Encoder path {stored!r} from the checkpoint does not exist on this machine. "
                     "Set HUBERT_NAME_OVERRIDE (or --hubert_name) to a local copy or a Hugging Face name.")


# =========================================================================== #
# Teacher (NeMo Conformer SLURP) - loaded with the same patches as training
# =========================================================================== #
def load_teacher():
    from teacher_nemo import load_teacher_model
    print(f"Loading NeMo teacher from {ARGS.teacher_nemo} ...")
    return load_teacher_model(ARGS.teacher_nemo, DEVICE)


class TeacherRunner:
    def __init__(self, teacher):
        self.m = teacher
        self.tok = teacher.tokenizer
        self._gens = {}

    def _gen(self, beam):
        from teacher_nemo import make_nemo_generator
        if beam not in self._gens:
            self._gens[beam] = make_nemo_generator(self.m.embedding, self.m.decoder,
                                                   self.m.classifier, self.tok, beam_size=beam)
        return self._gens[beam]

    @torch.no_grad()
    def predict(self, wav, beam):
        from nemo.collections.asr.parts.utils.slu_utils import get_seq_mask
        from teacher_nemo import run_generator, tokens_to_id_lists
        lens = torch.tensor([wav.shape[1]], device=DEVICE)
        f, fl = self.m.preprocessor(input_signal=wav, length=lens)
        enc, el = self.m.encoder(audio_signal=f, length=fl)
        enc = enc.transpose(1, 2)
        tokens = run_generator(self._gen(beam), enc, get_seq_mask(enc, el))
        ids = tokens_to_id_lists(tokens, self.tok.bos_id, self.tok.eos_id)[0]
        return "".join(self.tok.tokenizer.decode_ids(ids))


# =========================================================================== #
# Type A: sequence-KD student (best_student.pt)
# =========================================================================== #
class SeqStudentRunner:
    kind = "seq"

    def __init__(self, ckpt, teacher):
        from model_seq import HubertSemanticSLU
        from seq_dataset import CharVocab
        cfg = ckpt["config"]
        self.tok = teacher.tokenizer
        self.model = HubertSemanticSLU(
            teacher, hubert_name=resolve_encoder_name(cfg["hubert_name"]), layer_fusion=cfg["layer_fusion"],
            semantic_layer=cfg["semantic_layer"],
            fusion_layers=[int(x) for x in cfg["fusion_layers"].split(",")] if cfg["fusion_layers"] else None,
            adapter_layers=cfg["adapter_layers"], ctc_vocab_size=cfg.get("ctc_vocab_size", 0),
        )
        self.model.load_state_dict(ckpt["state_dict"])
        self.model.to(DEVICE).eval()
        self.char_vocab = CharVocab(ckpt["ctc_chars"]) if ckpt.get("ctc_chars") else None
        self.description = f"Sequence-KD student ({cfg['hubert_name']} encoder + Transformer decoder)"
        self._gens = {}

    def _gen(self, beam):
        if beam not in self._gens:
            self._gens[beam] = self.model.build_generator(self.tok, beam_size=beam)
        return self._gens[beam]

    @torch.no_grad()
    def predict(self, wav, beam):
        att = torch.ones_like(wav, dtype=torch.long)
        bos, eos = self.tok.bos_id, self.tok.eos_id
        if beam <= 1:
            ids, ctc = self.model.greedy(wav, att, bos, eos, max_len=128, return_ctc=True)
        else:
            ids, ctc = self.model.beam_search(wav, att, self._gen(beam), bos, eos, return_ctc=True)
        raw = "".join(self.tok.tokenizer.decode_ids(ids[0]))
        transcript = ""
        if ctc is not None and self.char_vocab is not None:
            transcript = self.char_vocab.decode_ctc(ctc[0])
        return raw, transcript


# =========================================================================== #
# Type B: CTC student (best_model.pt from train.py / train_kd.py)
# =========================================================================== #
class CTCStudentRunner:
    kind = "ctc"

    def __init__(self, state_dict, ckpt_path):
        from model import HubertSLUModel
        from vocab import CTCVocab
        ckpt_dir = Path(ckpt_path).parent
        cfg = {"hubert_name": CTC_HUBERT_NAME, "semantic_layer": CTC_SEMANTIC_LAYER,
               "layer_fusion": CTC_LAYER_FUSION, "fusion_layers": CTC_FUSION_LAYERS,
               "vocab_type": CTC_VOCAB_TYPE}
        for name in ("kd_args.json", "args.json", "train_args.json"):
            if (ckpt_dir / name).exists():
                saved = json.loads((ckpt_dir / name).read_text())
                cfg.update({k: saved[k] for k in cfg if k in saved})
                print(f"Read model settings from {ckpt_dir / name}")
                break

        self.intent_list = json.loads((ckpt_dir / "intent_labels.json").read_text())
        if cfg["vocab_type"] == "bpe":
            from vocab_bpe import BPECTCVocab
            self.vocab = BPECTCVocab.load(ckpt_dir / "bpe_tokenizer.json")
        else:
            self.vocab = CTCVocab.load(ckpt_dir / "ctc_vocab.json")

        fl = cfg["fusion_layers"]
        self.model = HubertSLUModel(
            num_intents=len(self.intent_list), ctc_vocab_size=len(self.vocab),
            pad_id=self.vocab.pad_id, blank_id=self.vocab.blank_id,
            hubert_name=resolve_encoder_name(cfg["hubert_name"]), semantic_layer=cfg["semantic_layer"],
            layer_fusion=cfg["layer_fusion"],
            fusion_layers=[int(x) for x in fl.split(",")] if fl else None,
        )
        self.model.load_state_dict(state_dict)
        self.model.to(DEVICE).eval()
        self.description = (f"CTC student ({cfg['hubert_name']}, {cfg['layer_fusion']} fusion, "
                            f"{len(self.intent_list)} intents)")

    @torch.no_grad()
    def predict(self, wav, beam=None):
        from vocab import extract_slots_from_tagged_text, strip_tags
        att = torch.ones(wav.shape, dtype=torch.long, device=DEVICE)
        out = self.model(wav, att)
        probs = torch.softmax(out["intent_logits"][0], -1)
        conf, idx = probs.max(-1)
        intent = self.intent_list[idx.item()]
        greedy = out["ctc_log_probs"].argmax(-1).transpose(0, 1)[0]
        L = int(out["feat_lens"][0].item())
        tagged = self.vocab.decode(greedy[:L].tolist())
        scenario, _, action = intent.partition("_")
        result = {
            "scenario": scenario,
            "action": action,
            "entities": [{"type": t, "filler": f} for t, f in extract_slots_from_tagged_text(tagged)],
            "intent_confidence": round(conf.item(), 4),
        }
        return json.dumps(result), strip_tags(tagged)


# =========================================================================== #
# Third model: RoBISLU (code_RoBISLU/train.py -> best_model.pt)
# =========================================================================== #
# code_RoBISLU has its own model.py / vocab.py with the SAME file names as the Code
# folder but different contents, so they are loaded under unique module names.
def _load_module_from(path, name, vocab_module=None):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    saved_vocab = sys.modules.get("vocab")
    if vocab_module is not None:          # vocab_bpe.py does "from vocab import ..."
        sys.modules["vocab"] = vocab_module
    try:
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
    finally:
        if vocab_module is not None:
            if saved_vocab is None:
                sys.modules.pop("vocab", None)
            else:
                sys.modules["vocab"] = saved_vocab
    return mod


ROBISLU_PUBLIC = {   # (encoder type, hidden size, layers) -> public model with that architecture
    ("wavlm", 768, 12): "microsoft/wavlm-base-plus",
    ("wavlm", 1024, 24): "microsoft/wavlm-large",
    ("hubert", 768, 12): "facebook/hubert-base-ls960",
    ("hubert", 1024, 24): "facebook/hubert-large-ll60k",
    ("wav2vec2", 768, 12): "facebook/wav2vec2-base",
    ("wav2vec2", 1024, 24): "facebook/wav2vec2-large-lv60",
}


def _detect_robislu_arch(sd):
    """Read the architecture from the checkpoint's weight names and shapes."""
    layers = {int(k.split(".")[3]) for k in sd if k.startswith("hubert.encoder.layers.")}
    if not layers or "intent_head.weight" not in sd or "ctc_head.weight" not in sd:
        raise SystemExit("RoBISLU checkpoint does not look like a code_RoBISLU HubertSLUModel "
                         "(missing hubert.encoder.layers / intent_head / ctc_head weights).")
    if any("gru_rel_pos" in k for k in sd):
        enc_type = "wavlm"
    elif "feat_norm.weight" in sd:          # model.py adds feat_norm only for wav2vec2
        enc_type = "wav2vec2"
    else:
        enc_type = "hubert"
    lstm_layers = sum(1 for k in sd if k.startswith("slot_lstm.weight_ih_l") and not k.endswith("_reverse"))
    return {
        "type": enc_type,
        "hidden": sd["intent_head.weight"].shape[1],
        "num_layers": max(layers) + 1,
        "num_intents": sd["intent_head.weight"].shape[0],
        "ctc_size": sd["ctc_head.weight"].shape[0],
        "fusion": "weighted_sum" if "intent_layer_fusion.raw_weights" in sd else "single",
        "n_fused": sd["intent_layer_fusion.raw_weights"].numel() if "intent_layer_fusion.raw_weights" in sd else 0,
        "lstm_hidden": sd["slot_lstm.weight_hh_l0"].shape[1],
        "lstm_layers": lstm_layers,
    }


def _robislu_encoder_name(wanted, arch):
    """Use `wanted` if it exists and has the checkpoint's architecture, else a public match."""
    from transformers import AutoConfig
    key = (arch["type"], arch["hidden"], arch["num_layers"])
    if wanted:
        local = wanted.startswith(("/", ".", "~"))
        if local and not os.path.isdir(os.path.expanduser(wanted)):
            print(f"[RoBISLU] encoder path {wanted!r} not found on this machine")
        else:
            try:
                c = AutoConfig.from_pretrained(os.path.expanduser(wanted))
                if (c.model_type, c.hidden_size, c.num_hidden_layers) == key:
                    return os.path.expanduser(wanted)
                print(f"[RoBISLU] {wanted!r} is {c.model_type}/{c.hidden_size}/{c.num_hidden_layers} layers, "
                      f"but the checkpoint was trained with {key[0]}/{key[1]}/{key[2]} layers")
            except Exception as e:
                print(f"[RoBISLU] could not read config of {wanted!r}: {e}")
    if key not in ROBISLU_PUBLIC:
        raise SystemExit(f"[RoBISLU] no known public encoder for {key}. "
                         "Set ROBISLU_HUBERT_NAME to the encoder you trained with.")
    print(f"[RoBISLU] using {ROBISLU_PUBLIC[key]!r} for the encoder architecture "
          "(fine-tuned weights are loaded from the checkpoint)")
    return ROBISLU_PUBLIC[key]


class RoBISLURunner:
    kind = "robislu"

    def __init__(self, code_dir, ckpt_path, ckpt_dir=None):
        code_dir = Path(code_dir)
        self.vocab_mod = _load_module_from(code_dir / "vocab.py", "robislu_vocab")
        model_mod = _load_module_from(code_dir / "model.py", "robislu_model")

        raw = torch.load(ckpt_path, map_location="cpu", weights_only=False)
        sd = raw["state_dict"] if isinstance(raw, dict) and "state_dict" in raw else raw
        sd = {(k[len("module."):] if k.startswith("module.") else k): v for k, v in sd.items()}
        arch = _detect_robislu_arch(sd)

        # --- labels + CTC vocab (pick whichever file matches the CTC head size)
        ckpt_dir = Path(ckpt_dir) if ckpt_dir else Path(ckpt_path).parent
        self.intent_list = json.loads((ckpt_dir / "intent_labels.json").read_text())
        if len(self.intent_list) != arch["num_intents"]:
            raise SystemExit(f"[RoBISLU] intent_labels.json has {len(self.intent_list)} intents but the "
                             f"checkpoint has {arch['num_intents']}: wrong ROBISLU_CKPT_DIR?")
        self.vocab, vocab_type, sizes = None, None, {}
        if (ckpt_dir / "ctc_vocab.json").exists():
            v = self.vocab_mod.CTCVocab.load(ckpt_dir / "ctc_vocab.json")
            sizes["ctc_vocab.json"] = len(v)
            if len(v) == arch["ctc_size"]:
                self.vocab, vocab_type = v, "char"
        if self.vocab is None and (ckpt_dir / "bpe_tokenizer.json").exists():
            bpe_mod = _load_module_from(code_dir / "vocab_bpe.py", "robislu_vocab_bpe", self.vocab_mod)
            v = bpe_mod.BPECTCVocab.load(ckpt_dir / "bpe_tokenizer.json")
            sizes["bpe_tokenizer.json"] = len(v)
            if len(v) == arch["ctc_size"]:
                self.vocab, vocab_type = v, "bpe"
        if self.vocab is None:
            raise SystemExit(f"[RoBISLU] no CTC vocab in {ckpt_dir} matches the checkpoint's CTC head "
                             f"({arch['ctc_size']} symbols); found {sizes or 'none'}")

        # --- layer fusion
        fusion_layers = None
        if arch["fusion"] == "weighted_sum":
            if ARGS.robislu_fusion_layers:
                fusion_layers = [int(x) for x in str(ARGS.robislu_fusion_layers).split(",")]
            elif arch["n_fused"] == arch["num_layers"] + 1:
                fusion_layers = list(range(0, arch["num_layers"] + 1))
            elif arch["n_fused"] != arch["num_layers"]:
                raise SystemExit(f"[RoBISLU] checkpoint fuses {arch['n_fused']} layers; set "
                                 "ROBISLU_FUSION_LAYERS to the --fusion_layers you trained with.")
            if fusion_layers is not None and len(fusion_layers) != arch["n_fused"]:
                raise SystemExit(f"[RoBISLU] ROBISLU_FUSION_LAYERS has {len(fusion_layers)} layers but "
                                 f"the checkpoint fuses {arch['n_fused']}.")
        else:
            print(f"[RoBISLU] single-layer model: using hidden_states[{ARGS.robislu_semantic_layer}] "
                  "(must equal --semantic_layer used in training)")

        enc_name = _robislu_encoder_name(ARGS.robislu_hubert_name, arch)
        self.model = model_mod.HubertSLUModel(
            num_intents=arch["num_intents"], ctc_vocab_size=arch["ctc_size"],
            pad_id=self.vocab.pad_id, blank_id=self.vocab.blank_id,
            hubert_name=enc_name, semantic_layer=ARGS.robislu_semantic_layer,
            layer_fusion=arch["fusion"], fusion_layers=fusion_layers,
            slot_lstm_hidden=arch["lstm_hidden"], slot_lstm_layers=arch["lstm_layers"],
        )
        self.model.load_state_dict(sd)          # strict: any mismatch raises here
        self.model.to(DEVICE).eval()
        fused = (f"weighted sum of {arch['n_fused']} layers" if arch["fusion"] == "weighted_sum"
                 else f"layer {ARGS.robislu_semantic_layer}")
        self.description = (f"RoBISLU ({arch['type']} {arch['hidden']}-d, {fused}, "
                            f"{vocab_type} CTC, {arch['num_intents']} intents)")

    @torch.no_grad()
    def predict(self, wav, beam=None):
        att = torch.ones(wav.shape, dtype=torch.long, device=DEVICE)
        out = self.model(wav, att)
        probs = torch.softmax(out["intent_logits"][0], -1)
        conf, idx = probs.max(-1)
        intent = self.intent_list[idx.item()]
        greedy = out["ctc_log_probs"].argmax(-1).transpose(0, 1)[0]
        L = int(out["feat_lens"][0].item())
        tagged = self.vocab.decode(greedy[:L].tolist())
        scenario, _, action = intent.partition("_")
        result = {
            "scenario": scenario,
            "action": action,
            "entities": [{"type": t, "filler": f}
                         for t, f in self.vocab_mod.extract_slots_from_tagged_text(tagged)],
            "intent_confidence": round(conf.item(), 4),
        }
        return json.dumps(result), self.vocab_mod.strip_tags(tagged)


def count_params(module):
    return sum(p.numel() for p in module.parameters()) if module is not None else 0


# =========================================================================== #
# Load everything
# =========================================================================== #
print(f"Loading your model from {ARGS.ckpt} (device={DEVICE}) ...")
_raw = torch.load(ARGS.ckpt, map_location="cpu", weights_only=False)
IS_SEQ = isinstance(_raw, dict) and "state_dict" in _raw and "config" in _raw

TEACHER_MODEL = None
if IS_SEQ or (not ARGS.no_teacher and os.path.exists(ARGS.teacher_nemo)):
    TEACHER_MODEL = load_teacher()

STUDENT = SeqStudentRunner(_raw, TEACHER_MODEL) if IS_SEQ else CTCStudentRunner(_raw, ARGS.ckpt)
TEACHER = TeacherRunner(TEACHER_MODEL) if TEACHER_MODEL is not None else None
del _raw
print(f"Loaded: {STUDENT.description}")

ROBISLU = None
if ARGS.no_robislu:
    print("RoBISLU disabled (--no_robislu)")
elif not os.path.exists(ARGS.robislu_ckpt):
    print(f"WARNING: RoBISLU checkpoint not found: {ARGS.robislu_ckpt} -> RoBISLU panel hidden")
else:
    print(f"Loading RoBISLU from {ARGS.robislu_ckpt} ...")
    ROBISLU = RoBISLURunner(ARGS.robislu_code_dir, ARGS.robislu_ckpt, ARGS.robislu_ckpt_dir)
    print(f"Loaded: {ROBISLU.description}")

PARAMS = {"RoboAD": count_params(STUDENT.model),
          "RoBISLU": count_params(ROBISLU.model) if ROBISLU else 0,
          "NeMo Conformer": count_params(TEACHER_MODEL)}


# =========================================================================== #
# Audio + noise helpers (same behaviour as app3.py)
# =========================================================================== #
def scan_noise_dir(noise_dir):
    """Return {class_name: [(file_name, full_path), ...]} for every sub-folder."""
    catalog = {}
    if not os.path.isdir(noise_dir):
        print(f"WARNING: noise folder not found: {noise_dir}")
        return catalog
    for cls_name in sorted(os.listdir(noise_dir)):
        cls_path = os.path.join(noise_dir, cls_name)
        if not os.path.isdir(cls_path):
            continue
        files = [(f, os.path.join(cls_path, f)) for f in sorted(os.listdir(cls_path))
                 if f.lower().endswith(AUDIO_EXTS)]
        if files:
            catalog[cls_name] = files
    return catalog


NOISE_CATALOG = scan_noise_dir(ARGS.noise_dir)
NOISE_CLASSES = list(NOISE_CATALOG.keys())
print(f"Found noise classes: {NOISE_CLASSES}")


def load_audio(path):
    audio, _ = librosa.load(path, sr=TARGET_SR, mono=True)
    return audio.astype(np.float32)


def add_noise_at_snr(speech, noise, snr_db, rng=None):
    rng = rng or np.random.default_rng()
    if len(noise) < len(speech):
        noise = np.tile(noise, int(np.ceil(len(speech) / len(noise))))
    start = rng.integers(0, len(noise) - len(speech) + 1)
    noise = noise[start:start + len(speech)]
    speech_power, noise_power = np.mean(speech ** 2), np.mean(noise ** 2)
    if speech_power == 0 or noise_power == 0:
        return speech
    scale = np.sqrt(speech_power / (noise_power * 10 ** (snr_db / 10)))
    mixed = speech + scale * noise
    peak = np.max(np.abs(mixed))
    if peak > 0.99:
        mixed = mixed * (0.99 / peak)
    return mixed.astype(np.float32)


def save_temp_wav(audio):
    fd, path = tempfile.mkstemp(suffix=".wav")
    os.close(fd)
    sf.write(path, audio, TARGET_SR)
    return path


def pretty(raw):
    """Model string -> pretty JSON (falls back to the raw string)."""
    try:
        d = json.loads(raw)
    except Exception:
        d = parse_semantics(raw)
    return json.dumps(d, indent=4) if d else raw


def sync():
    if DEVICE.startswith("cuda"):
        torch.cuda.synchronize()


# =========================================================================== #
# Gradio callbacks
# =========================================================================== #
def to_dict(text):
    """Model output string (JSON or NeMo '|' format) -> dict, or None."""
    try:
        d = json.loads(text)
        return d if isinstance(d, dict) else None
    except Exception:
        return parse_semantics(text)


def _intent(d):
    return f"{d.get('scenario', '')}_{d.get('action', '')}" if d else None


def _slots(d):
    if not d:
        return set()
    return {(str(e.get("type", "")).strip().lower(), str(e.get("filler", "")).strip().lower())
            for e in d.get("entities", []) if isinstance(e, dict)}


def _md(x):
    return str(x).replace("|", "\\|")


def comparison_table(results):
    """results: list of (name, dict or None, seconds or None, error or None)."""
    if not results:
        return ""
    ref = next((d for n, d, _, _ in results if n == "NeMo Conformer"), None)
    names = [n for n, _, _, _ in results]
    rows = [("Intent", []), ("Slots", []), ("Inference time", []), ("Model size", [])]
    if ref is not None:
        rows += [("Same intent as NeMo", []), ("Same slots as NeMo", [])]
    for name, d, sec, err in results:
        if err:
            vals = [f"error: {err}", "", "", ""]
        else:
            seen = []
            for e in (d or {}).get("entities", []):
                if isinstance(e, dict):
                    item = f"{e.get('type', '')} = {e.get('filler', '')}"
                    if item not in seen:
                        seen.append(item)
            ents = "; ".join(seen) or "(none)"
            vals = [_intent(d) or "(unparsable)", ents, f"{sec * 1000:.0f} ms",
                    f"{PARAMS.get(name, 0) / 1e6:.1f} M params"]
        if ref is not None:
            if name == "NeMo Conformer":
                vals += ["reference", "reference"]
            elif err or d is None:
                vals += ["—", "—"]
            else:
                vals += ["✅ yes" if _intent(d) == _intent(ref) else "❌ no",
                         "✅ yes" if _slots(d) == _slots(ref) else "❌ no"]
        for (_, cells), v in zip(rows, vals):
            cells.append(v)
    out = ["### Comparison of the three models (same audio)", "",
           "| | " + " | ".join(f"**{_md(n)}**" for n in names) + " |",
           "|---|" + "---|" * len(names)]
    out += ["| **" + label + "** | " + " | ".join(_md(c) for c in cells) + " |" for label, cells in rows]
    return "\n".join(out)


def _run(runner, wav, beam):
    """-> (raw string, transcript, seconds, error message)."""
    try:
        t0 = time.perf_counter()
        out = runner.predict(wav, beam)
        sync()
        sec = time.perf_counter() - t0
        raw, transcript = out if isinstance(out, tuple) else (out, "")
        return raw, transcript, sec, None
    except Exception as e:
        return None, "", None, str(e)


def _prefill(student_d, robislu_d, teacher_d, student_tr, robislu_tr):
    """Pre-fill the correction box with the best available answer."""
    d = student_d or teacher_d or robislu_d
    if not d:
        return "", "", ""
    ents = [(e.get("type", ""), e.get("filler", "")) for e in d.get("entities", []) if isinstance(e, dict)]
    transcript = robislu_tr or student_tr or ""
    return d.get("scenario", ""), d.get("action", ""), build_annotation(transcript, ents)


def analyse(audio_path, use_noise, noise_path, snr_db, beam, compare, compare_robislu, remember):
    def fail(msg):
        return (None, msg, "", "", "", "", "", "",
                gr.update(), gr.update(), gr.update(), None)
    if audio_path is None:
        return fail("Please upload or record an audio file")
    try:
        clean = load_audio(audio_path)
        speech = clean
        if use_noise:
            if not noise_path:
                return fail("Please select a noise sample, or untick 'Add background noise'")
            speech = add_noise_at_snr(clean, load_audio(noise_path), float(snr_db))
        model_input = save_temp_wav(speech)
        wav = torch.from_numpy(speech).unsqueeze(0).to(DEVICE)
        beam = int(beam)
    except Exception as e:
        return fail(f"An error occurred while preparing the audio: {e}")

    results, info_parts, dicts = [], [], {}
    with ADAPT.lock:      # never run while the models are being adapted
        # 1) RoboAD (your main model)
        raw, transcript, sec, err = _run(STUDENT, wav, beam)
        student_out = f"An error occurred during inference: {err}" if err else pretty(raw)
        dicts["RoboAD"] = None if err else to_dict(raw)
        results.append(("RoboAD", dicts["RoboAD"], sec, err))
        if not err:
            ADAPT.observe_raw(raw)
            info_parts.append(f"**RoboAD:** {sec * 1000:.0f} ms")

        # 2) RoBISLU
        robislu_out, robislu_transcript = "", ""
        if compare_robislu and ROBISLU is not None:
            raw, robislu_transcript, sec, err = _run(ROBISLU, wav, beam)
            robislu_out = f"An error occurred during inference: {err}" if err else pretty(raw)
            dicts["RoBISLU"] = None if err else to_dict(raw)
            results.append(("RoBISLU", dicts["RoBISLU"], sec, err))
            if not err:
                info_parts.append(f"**RoBISLU:** {sec * 1000:.0f} ms")

        # 3) NeMo Conformer (teacher)
        teacher_out = ""
        if compare and TEACHER is not None:
            raw, _, sec, err = _run(TEACHER, wav, beam)
            teacher_out = f"An error occurred during inference: {err}" if err else pretty(raw)
            dicts["NeMo Conformer"] = None if err else to_dict(raw)
            results.append(("NeMo Conformer", dicts["NeMo Conformer"], sec, err))
            if not err:
                ADAPT.observe_raw(raw)
                info_parts.append(f"**NeMo teacher:** {sec * 1000:.0f} ms")

    info = "  |  ".join(info_parts) + f"  |  audio {len(speech) / TARGET_SR:.1f} s on {DEVICE}"
    if use_noise:
        info += f", noise at {snr_db} dB SNR"
    table = comparison_table(results) if len(results) > 1 else ""

    # remember the clip (anchor = "keep answering like this" during later adaptation)
    anchor_id = None
    if remember:
        preds = {}
        for name, d in dicts.items():
            if d:
                tr = robislu_transcript if name == "RoBISLU" else (transcript if name == "RoboAD" else "")
                preds[name] = {**d, "_transcript": tr}
        if preds:
            try:
                anchor_id = ADAPT.add_anchor(clean, speech, preds)
            except Exception as e:
                print(f"[adapt] could not store anchor: {e}")
    sc, ac, ann = _prefill(dicts.get("RoboAD"), dicts.get("RoBISLU"), dicts.get("NeMo Conformer"),
                           transcript, robislu_transcript)
    state = {"clean": clean, "noisy": speech, "anchor": anchor_id}
    return (model_input, student_out, transcript, robislu_out, robislu_transcript,
            teacher_out, info, table, sc, ac, ann, state)


# --------------------------------------------------------------------------- #
# Learning from corrections
# --------------------------------------------------------------------------- #
def corrections_md():
    items = ADAPT.corrections()
    if not items:
        return "_No corrections saved yet._"
    rows = ["| Saved | Intent | Sentence with slots |", "|---|---|---|"]
    for c in items[-10:][::-1]:
        when = time.strftime("%d %b %H:%M", time.localtime(c["time"]))
        rows.append(f"| {when} | {c['scenario']}_{c['action']} | {_md(c['annotation'])} |")
    more = f"\n\n{len(items)} correction(s) in total." if len(items) > 10 else ""
    return f"**Saved corrections ({len(items)})**\n\n" + "\n".join(rows) + more


def store_md():
    replay = len(ADAPT.replay_train) + len(ADAPT.replay_eval)
    return (f"Old-knowledge protection: **{replay}** replay clips"
            + ("" if replay else " (none: run make_replay_set.py for the best protection)")
            + f", **{len(ADAPT.anchors())}** anchor clips. Adapted models loaded at start: "
            + (", ".join(ADAPTED_AT_START) or "none") + ".")


def save_correction(state, scenario, action, annotation):
    if not state:
        return "Analyse a clip first, then correct its answer here.", corrections_md(), store_md()
    cid, err = ADAPT.add_correction(state["clean"], state["noisy"], scenario, action, annotation,
                                    from_anchor=state.get("anchor"))
    if err:
        return f"Not saved: {err}", corrections_md(), store_md()
    return (f"Saved correction **{scenario.strip().lower()}_{action.strip().lower()}**. "
            "Add more examples or click *Adapt models now*."), corrections_md(), store_md()


def undo_correction():
    c = ADAPT.delete_last_correction()
    msg = f"Deleted: {c['scenario']}_{c['action']} — {c['annotation']}" if c else "Nothing to delete."
    return msg, corrections_md(), store_md()


def run_adapt(models, steps):
    if not models:
        yield "Select at least one model.", "", store_md()
        return
    log = []
    for line in ADAPT.adapt(list(models), steps=int(steps)):
        log.append(line)
        yield "\n\n".join(log[-12:]), "", store_md()
    yield "\n\n".join(log[-12:]), results_table(getattr(ADAPT, "last_results", [])), store_md()


def reset_models():
    moved = ADAPT.reset()
    if not moved:
        return "No adapted weights to reset."
    return (f"Adapted weights of {', '.join(moved)} moved to {ARGS.adapt_store}/archive. "
            "**Restart the app** to use the original models. Saved corrections are kept.")


def noise_choices(cls_name):
    return [(name, path) for name, path in NOISE_CATALOG.get(cls_name, [])]


def on_class_change(cls_name):
    choices = noise_choices(cls_name)
    first = choices[0][1] if choices else None
    return gr.update(choices=choices, value=first), first


# =========================================================================== #
# Adaptation manager (learning from corrections)
# =========================================================================== #
from adaptation import (AdaptationManager, NemoUpdater, RoBISLUUpdater, RoboADUpdater,  # noqa: E402
                        build_annotation, results_table)


def _predictor(runner, kind):
    def f(audio):
        wav = torch.from_numpy(audio).unsqueeze(0).to(DEVICE)
        out = runner.predict(wav, 1)                 # greedy: fast scoring
        return to_dict(out[0] if isinstance(out, tuple) else out)
    return f


_predictors, _updaters = {}, {}
if STUDENT.kind == "seq":
    _predictors["RoboAD"] = _predictor(STUDENT, "seq")
    _updaters["RoboAD"] = RoboADUpdater(STUDENT, top_layers=ARGS.adapt_top_layers)
if ROBISLU is not None:
    _predictors["RoBISLU"] = _predictor(ROBISLU, "robislu")
    _updaters["RoBISLU"] = RoBISLUUpdater(ROBISLU, top_layers=ARGS.adapt_top_layers)
if TEACHER is not None:
    _predictors["NeMo Conformer"] = _predictor(TEACHER, "nemo")
    _updaters["NeMo Conformer"] = NemoUpdater(TEACHER_MODEL, top_layers=ARGS.adapt_top_layers)

ADAPT = AdaptationManager(
    ARGS.adapt_store, DEVICE,
    noise_files=[p for files in NOISE_CATALOG.values() for _, p in files],
    replay_dir=ARGS.replay_dir, predictors=_predictors, updaters=_updaters,
    tolerance=ARGS.adapt_tolerance)
ADAPTABLE = list(_updaters)
ADAPTED_AT_START = [] if ARGS.no_adapted else ADAPT.load_active()
PARAMS.update({"RoBISLU": count_params(ROBISLU.model) if ROBISLU else 0})   # heads may have grown
print(f"[adapt] store={ARGS.adapt_store}  adaptable={ADAPTABLE}  loaded adapted={ADAPTED_AT_START}  "
      f"replay clips={len(ADAPT.replay_train) + len(ADAPT.replay_eval)}")


# =========================================================================== #
# UI
# =========================================================================== #
TITLE = "Noise-Robust SLU Demo (RoboAD (Robust optimized Adapter Decoder) Model)"

with gr.Blocks(title=TITLE) as demo:
    gr.Markdown(f"# {TITLE}")
    gr.Markdown(
        f"This web interface runs **RoboAD model** — {STUDENT.description} — "
        "trained on SLURP for joint intent classification and slot filling. "
        "You can mix background noise into your speech at a chosen SNR to test how robust "
        "it is, and compare its prediction with the original NVIDIA NeMo Conformer model"
        + (f" and with **RoBISLU** — {ROBISLU.description}." if ROBISLU is not None else ".")
    )

    with gr.Row():
        with gr.Column():
            audio_input = gr.Audio(sources=["microphone", "upload"], type="filepath",
                                   label="Input Speech")

            use_noise = gr.Checkbox(label="Add background noise", value=False)
            with gr.Group(visible=False) as noise_box:
                default_class = NOISE_CLASSES[0] if NOISE_CLASSES else None
                default_choices = noise_choices(default_class)
                default_noise = default_choices[0][1] if default_choices else None
                noise_class = gr.Dropdown(choices=NOISE_CLASSES, value=default_class,
                                          label="Noise class")
                noise_sample = gr.Dropdown(choices=default_choices, value=default_noise,
                                           label="Noise sample")
                noise_preview = gr.Audio(value=default_noise, type="filepath",
                                         label="Noise preview", interactive=False)
                snr = gr.Radio(choices=SNR_OPTIONS, value=SNR_OPTIONS[-1], label="SNR (dB)")

            beam = gr.Radio(choices=BEAM_OPTIONS,
                            value=32 if DEVICE.startswith("cuda") else 4,
                            label="Beam size for RoboAD and NeMo (1 = greedy, fastest; 32 = published "
                                  "SLURP setting). RoBISLU always uses greedy CTC.",
                            visible=STUDENT.kind == "seq" or TEACHER is not None)
            compare = gr.Checkbox(label="Compare with NeMo Conformer (teacher)",
                                  value=TEACHER is not None, visible=TEACHER is not None)
            compare_robislu = gr.Checkbox(label="Compare with RoBISLU",
                                          value=ROBISLU is not None, visible=ROBISLU is not None)

            submit_btn = gr.Button("Analyse speech", variant="primary")

        with gr.Column():
            model_audio = gr.Audio(type="filepath", interactive=False,
                                   label="Audio sent to the models (16 kHz mono, with noise if selected)")
            info = gr.Markdown()
            table = gr.Markdown()

    with gr.Row(equal_height=False):
        with gr.Column():
            output_text = gr.Code(label="RoboAD (Robust optimized Adapter Decoder) — Extracted Semantics (Intent and Slots)",
                                  language="json")
            transcript = gr.Textbox(label="RoboAD (Robust optimized Adapter Decoder) — Transcript (CTC head)", interactive=False,
                                    visible=STUDENT.kind == "ctc" or getattr(STUDENT, "char_vocab", None) is not None)
        with gr.Column(visible=ROBISLU is not None) as robislu_col:
            robislu_text = gr.Code(label="RoBISLU — Extracted Semantics (Intent and Slots)",
                                   language="json")
            robislu_transcript = gr.Textbox(label="RoBISLU — Transcript (CTC head)", interactive=False)
        with gr.Column(visible=TEACHER is not None) as teacher_col:
            teacher_text = gr.Code(label="NeMo Conformer (teacher) — Extracted Semantics",
                                   language="json")

    last_state = gr.State(None)
    with gr.Accordion("Teach the models: correct a wrong answer, then adapt", open=False):
        gr.Markdown(
            "1. Analyse a clip. The box below is filled with the current answer.  \n"
            "2. Fix the scenario, action and sentence. Write slots as **[slot_type : words]**, "
            "e.g. `wake me up at [time : five am]`, and click **Save correction**. "
            "New intents and slot types are allowed.  \n"
            "3. After one or more corrections, click **Adapt models now**. Each model is checked "
            "before and after; an update that harms old knowledge is rolled back automatically.")
        with gr.Row():
            corr_scenario = gr.Textbox(label="Scenario", placeholder="alarm")
            corr_action = gr.Textbox(label="Action", placeholder="set")
        corr_annotation = gr.Textbox(label="What was said, with slots as [slot_type : words]",
                                     placeholder="wake me up at [time : five am]")
        with gr.Row():
            save_btn = gr.Button("Save correction", variant="primary")
            undo_btn = gr.Button("Delete last correction")
        corr_status = gr.Markdown()
        corr_list = gr.Markdown(value=corrections_md)
        remember = gr.Checkbox(label="Remember analysed clips as anchors (protects old knowledge)",
                               value=True)
        with gr.Row():
            adapt_models = gr.CheckboxGroup(choices=ADAPTABLE, value=ADAPTABLE, label="Models to adapt")
            adapt_steps = gr.Slider(10, 200, value=40, step=10, label="Training steps per model")
        adapt_btn = gr.Button("Adapt models now", variant="primary")
        adapt_status = gr.Markdown()
        adapt_table = gr.Markdown()
        store_info = gr.Markdown(value=store_md)
        reset_btn = gr.Button("Reset to original models (after restart)")
        reset_status = gr.Markdown()

    save_btn.click(save_correction, inputs=[last_state, corr_scenario, corr_action, corr_annotation],
                   outputs=[corr_status, corr_list, store_info])
    undo_btn.click(undo_correction, outputs=[corr_status, corr_list, store_info])
    adapt_btn.click(run_adapt, inputs=[adapt_models, adapt_steps],
                    outputs=[adapt_status, adapt_table, store_info])
    reset_btn.click(reset_models, outputs=reset_status)

    use_noise.change(lambda v: gr.update(visible=v), inputs=use_noise, outputs=noise_box)
    noise_class.change(on_class_change, inputs=noise_class, outputs=[noise_sample, noise_preview])
    noise_sample.change(lambda p: p, inputs=noise_sample, outputs=noise_preview)
    compare.change(lambda v: gr.update(visible=v), inputs=compare, outputs=teacher_col)
    compare_robislu.change(lambda v: gr.update(visible=v), inputs=compare_robislu, outputs=robislu_col)

    submit_btn.click(
        fn=analyse,
        inputs=[audio_input, use_noise, noise_sample, snr, beam, compare, compare_robislu, remember],
        outputs=[model_audio, output_text, transcript, robislu_text, robislu_transcript,
                 teacher_text, info, table, corr_scenario, corr_action, corr_annotation, last_state],
    )

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=ARGS.port, allowed_paths=[ARGS.noise_dir])
