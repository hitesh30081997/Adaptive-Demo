"""
adaptation.py
Learn from user corrections in the dashboard WITHOUT forgetting what the models
already know (continual learning). Used by app_student.py.

What happens when you click "Adapt models":
  1. Training data for each model = your saved corrections (each also replayed with
     different background noises and SNRs, so the model learns the command in many
     environments) MIXED with "old" examples that protect existing knowledge:
       - replay set  : a small labelled SLURP sample copied to this machine
                       (make it once with make_replay_set.py; strongest protection)
       - anchor clips: clips analysed in this dashboard, with the answer the model
                       gave at that time (self-distillation: "keep answering like this")
  2. Only the upper part of each model is updated (decoder / heads / adapter + the
     top encoder layers), with a small learning rate and a few steps.
  3. Before and after the update each model is scored on the corrections and on
     held-out old examples. The update is KEPT only if the corrections did not get
     worse and the old score did not drop by more than `tolerance`; otherwise the
     model is rolled back automatically.
  4. Kept updates are saved under <store>/models/<model>/active.pt and loaded again
     when the app starts; every version is also kept in history/.

New commands: RoboAD and NeMo write the intent as text, so new intents / slot types
need no change. RoBISLU gets a new output row for each new intent, and (char vocab)
a new tag for each new slot type.
"""
import copy
import json
import random
import re
import shutil
import threading
import time
import uuid
from pathlib import Path

import numpy as np
import soundfile as sf
import torch
import torch.nn as nn
import torch.nn.functional as F

TARGET_SR = 16000
AUG_SNRS = [None, 20, 10, 5, 0]          # None = the clip as recorded
ANCHOR_MAX = 300                          # anchor clips kept (oldest dropped first)

_BRACKET_RE = re.compile(r"\[\s*([^:\]]+?)\s*:\s*([^\]]*?)\s*\]")


# =========================================================================== #
# Label helpers
# =========================================================================== #
def normalize_text(text):
    text = re.sub(r"[^a-z0-9' ]+", " ", (text or "").lower())
    return re.sub(r"\s+", " ", text).strip()


def parse_annotation(annotation):
    """'wake me up at [time : five am]' -> ([('time', 'five am')], 'wake me up at five am').
    Same entity rule as NeMo's process_slurp_data / semantics_utils.nemo_entities."""
    ann = (annotation or "").strip().lower()
    ents = [(t.strip().replace(" ", "_"), normalize_text(f)) for t, f in _BRACKET_RE.findall(ann)]
    ents = [(t, f) for t, f in ents if t and f]
    transcript = normalize_text(_BRACKET_RE.sub(lambda m: m.group(2), ann))
    return ents, transcript


def clean_annotation(annotation):
    """Normalised annotation text used as the RoBISLU CTC target."""
    ann = (annotation or "").strip().lower()
    out, pos = [], 0
    for m in _BRACKET_RE.finditer(ann):
        out.append(normalize_text(ann[pos:m.start()]))
        t, f = m.group(1).strip().replace(" ", "_"), normalize_text(m.group(2))
        if t and f:
            out.append(f"[{t} : {f}]")
        pos = m.end()
    out.append(normalize_text(ann[pos:]))
    return " ".join(x for x in out if x)


def build_annotation(transcript, entities):
    """Put [type : filler] brackets into a transcript where each filler occurs."""
    text = normalize_text(transcript)
    if not text:
        return ""
    words, used = text.split(" "), [False] * len(text.split(" "))
    spans = []
    for t, f in entities:
        fw = normalize_text(f).split(" ")
        if not fw or not fw[0]:
            continue
        for i in range(len(words) - len(fw) + 1):
            if words[i:i + len(fw)] == fw and not any(used[i:i + len(fw)]):
                spans.append((i, i + len(fw), t))
                for k in range(i, i + len(fw)):
                    used[k] = True
                break
    for s, e, t in sorted(spans, reverse=True):
        words[s:e] = [f"[{t} : {' '.join(words[s:e])}]"]
    return " ".join(words)


def validate_label(scenario, action, annotation):
    """-> (scenario, action, clean annotation, error or None)"""
    sc = (scenario or "").strip().lower().replace(" ", "_")
    ac = (action or "").strip().lower().replace(" ", "_")
    ann = (annotation or "").strip()
    if not sc or not ac:
        return sc, ac, ann, "Scenario and action are required."
    if "_" in sc:
        return sc, ac, ann, "Scenario must be one word (SLURP intents are scenario_action, e.g. alarm + set)."
    if not re.fullmatch(r"[a-z0-9_]+", sc + ac):
        return sc, ac, ann, "Scenario and action may only contain letters, digits and _."
    if ann.count("[") != ann.count("]"):
        return sc, ac, ann, "Brackets in the sentence are not balanced. Use [slot_type : words]."
    if "[" in ann and not _BRACKET_RE.search(ann):
        return sc, ac, ann, "Write each slot as [slot_type : words], e.g. [time : five am]."
    ann = clean_annotation(ann)
    if not parse_annotation(ann)[1]:
        return sc, ac, ann, "Please type what was said (the corrected sentence)."
    return sc, ac, ann, None


def sem_key(d):
    """Comparable (intent, slot set) of a prediction or label dict."""
    if not d:
        return None
    ents = set()
    for e in d.get("entities", []) or []:
        if isinstance(e, dict):
            t, f = e.get("type", ""), e.get("filler", "")
        else:
            t, f = e
        if t and f:
            ents.add((str(t).strip().lower(), normalize_text(str(f))))
    return (f"{d.get('scenario', '')}_{d.get('action', '')}".lower(), frozenset(ents))


def render_semantics(scenario, action, entities, sep="| "):
    """Teacher target string, identical to semantics_utils.render_semantics."""
    q = repr
    ents = sep.join("{" + f"'type': {q(t)}{sep}'filler': {q(f)}" + "}" for t, f in entities)
    return "{" + f"'scenario': {q(scenario)}{sep}'action': {q(action)}{sep}'entities': [{ents}]" + "}"


# =========================================================================== #
# Audio helpers
# =========================================================================== #
def load_wav(path):
    import librosa
    x, _ = librosa.load(str(path), sr=TARGET_SR, mono=True)
    return x.astype(np.float32)


def mix_snr(speech, noise, snr_db, rng):
    if len(noise) < len(speech):
        noise = np.tile(noise, int(np.ceil(len(speech) / len(noise))))
    s = rng.integers(0, len(noise) - len(speech) + 1)
    noise = noise[s:s + len(speech)]
    ps, pn = float(np.mean(speech ** 2)), float(np.mean(noise ** 2))
    if ps < 1e-10 or pn < 1e-10:
        return speech
    out = speech + np.sqrt(ps / (pn * 10 ** (snr_db / 10))) * noise
    peak = float(np.max(np.abs(out)))
    return (out * (0.99 / peak) if peak > 0.99 else out).astype(np.float32)


def pad_batch(wavs, device):
    n = max(len(w) for w in wavs)
    x = torch.zeros(len(wavs), n)
    att = torch.zeros(len(wavs), n, dtype=torch.long)
    for i, w in enumerate(wavs):
        x[i, :len(w)] = torch.from_numpy(w)
        att[i, :len(w)] = 1
    return x.to(device), att.to(device)


def _unwrap(x):
    return x[0] if isinstance(x, (tuple, list)) else x


def _seq_mask(enc, lens):
    try:
        from nemo.collections.asr.parts.utils.slu_utils import get_seq_mask
        return get_seq_mask(enc, lens)
    except ImportError:
        return torch.arange(enc.shape[1], device=enc.device)[None, :] < lens[:, None]


def _seq_targets(samples, tok, sep, device):
    """[BOS] + ids + [EOS] -> dec_inp, labels, mask (same layout as collate_semantics)."""
    tgts = [[tok.bos_id] + list(tok.text_to_ids(render_semantics(s["scenario"], s["action"],
                                                                 s["entities"], sep))) + [tok.eos_id]
            for s in samples]
    L = max(len(t) for t in tgts) - 1
    dec_inp = torch.zeros(len(tgts), L, dtype=torch.long)
    labels = torch.zeros(len(tgts), L, dtype=torch.long)
    mask = torch.zeros(len(tgts), L)
    for i, t in enumerate(tgts):
        k = len(t) - 1
        dec_inp[i, :k], labels[i, :k], mask[i, :k] = torch.tensor(t[:-1]), torch.tensor(t[1:]), 1.0
    return dec_inp.to(device), labels.to(device), mask.to(device)


def _masked_ce(logp, labels, mask):
    nll = -logp.gather(-1, labels.unsqueeze(-1)).squeeze(-1)
    return (nll * mask).sum() / mask.sum().clamp(min=1.0)


def _params_of(modules):
    out, seen = [], set()
    for m in modules:
        if m is None:
            continue
        for p in m.parameters():
            if id(p) not in seen:
                seen.add(id(p))
                out.append(p)
    return out


# =========================================================================== #
# Per-model updaters
# =========================================================================== #
class _Updater:
    """Common logic: choose trainable parameters, snapshot/rollback, save/load."""
    name = "?"

    def __init__(self, module, top_layers):
        self.module = module
        self.top_layers = top_layers

    # subclasses: groups() -> [(params, lr)], loss(samples, ctx) -> tensor, predict(wav) -> dict
    def trainable_names(self):
        ids = {id(p) for ps, _ in self.groups() for p in ps}
        return [n for n, p in self.module.named_parameters() if id(p) in ids]

    def prepare(self, samples):
        """Hook to grow the label space before training (RoBISLU)."""
        return []

    def snapshot(self):
        names = set(self.trainable_names())
        return {n: p.detach().to("cpu", copy=True) for n, p in self.module.named_parameters() if n in names}

    def restore(self, snap):
        params = dict(self.module.named_parameters())
        with torch.no_grad():
            for n, t in snap.items():
                params[n].copy_(t.to(params[n].device))

    def save(self, folder, changed_names):
        folder.mkdir(parents=True, exist_ok=True)
        f = folder / "active.pt"
        saved = torch.load(f, map_location="cpu", weights_only=False) if f.exists() else {"params": {}}
        params = dict(self.module.named_parameters())
        for n in changed_names:
            saved["params"][n] = params[n].detach().to("cpu", copy=True)
        torch.save(saved, f)
        return f

    def load(self, folder):
        f = folder / "active.pt"
        if not f.exists():
            return False
        saved = torch.load(f, map_location="cpu", weights_only=False)
        params = dict(self.module.named_parameters())
        unknown = [n for n in saved["params"] if n not in params]
        if unknown:
            raise RuntimeError(f"{self.name}: adapted file does not match this model ({unknown[:3]} ...)")
        with torch.no_grad():
            for n, t in saved["params"].items():
                params[n].copy_(t.to(params[n].device))
        return True

    @staticmethod
    def _top_layers_of(layers, k):
        return list(layers)[-k:] if (layers is not None and k > 0) else []


class RoboADUpdater(_Updater):
    """Sequence student (model_seq.HubertSemanticSLU) = RoboAD."""
    name = "RoboAD"

    def __init__(self, runner, top_layers=2, lr=5e-5, enc_lr=1e-5):
        super().__init__(runner.model, top_layers)
        self.runner, self.tok, self.lr, self.enc_lr = runner, runner.tok, lr, enc_lr

    def groups(self):
        m = self.module
        top = self._top_layers_of(getattr(m.hubert.encoder, "layers", None), self.top_layers)
        return [(_params_of(top), self.enc_lr),
                (list(m.bridge_parameters()) + list(m.decoder_parameters()), self.lr)]

    def loss(self, samples, ctx):
        wav, att = pad_batch([s["wav"] for s in samples], ctx["device"])
        dec_inp, labels, mask = _seq_targets(samples, self.tok, ctx["sep"], ctx["device"])
        out = self.module(wav, att, dec_inp, mask)
        return _masked_ce(out["log_probs"], labels, mask)


class NemoUpdater(_Updater):
    """NVIDIA NeMo Conformer SLU model (the teacher)."""
    name = "NeMo Conformer"

    def __init__(self, nemo_model, top_layers=2, lr=2e-5, enc_lr=5e-6):
        super().__init__(nemo_model, top_layers)
        self.tok, self.lr, self.enc_lr = nemo_model.tokenizer, lr, enc_lr

    def groups(self):
        m = self.module
        top = self._top_layers_of(getattr(m.encoder, "layers", None), self.top_layers)
        return [(_params_of(top), self.enc_lr),
                (_params_of([m.embedding, m.decoder, m.classifier]), self.lr)]

    def loss(self, samples, ctx):
        m = self.module
        wav, att = pad_batch([s["wav"] for s in samples], ctx["device"])
        feats, flens = m.preprocessor(input_signal=wav, length=att.sum(-1))
        enc, elens = m.encoder(audio_signal=feats, length=flens)
        enc = enc.transpose(1, 2)
        dec_inp, labels, mask = _seq_targets(samples, self.tok, ctx["sep"], ctx["device"])
        h = _unwrap(m.decoder(m.embedding(dec_inp), mask, enc, _seq_mask(enc, elens)))
        logp = torch.log_softmax(m.classifier(hidden_states=h).float(), dim=-1)
        return _masked_ce(logp, labels, mask)


class RoBISLUUpdater(_Updater):
    """code_RoBISLU HubertSLUModel: intent classifier + BiLSTM-CTC slot tagger."""
    name = "RoBISLU"

    def __init__(self, runner, top_layers=2, lr=5e-5, enc_lr=1e-5):
        super().__init__(runner.model, top_layers)
        self.runner, self.lr, self.enc_lr = runner, lr, enc_lr

    def groups(self):
        m = self.module
        top = self._top_layers_of(getattr(m.hubert.encoder, "layers", None), self.top_layers)
        heads = [m.intent_pool, m.intent_head, m.slot_lstm, m.ctc_head,
                 getattr(m, "intent_layer_fusion", None), getattr(m, "slot_layer_fusion", None),
                 getattr(m, "feat_norm", None)]
        return [(_params_of(top), self.enc_lr), (_params_of(heads), self.lr)]

    # ---- label space -------------------------------------------------------
    @property
    def _char_vocab(self):
        return hasattr(self.runner.vocab, "itos")

    def snapshot(self):
        snap = super().snapshot()
        r = self.runner
        snap["__meta__"] = {"intent_list": list(r.intent_list),
                            "itos": list(r.vocab.itos) if self._char_vocab else None,
                            "intent_head": copy.deepcopy(r.model.intent_head).cpu(),
                            "ctc_head": copy.deepcopy(r.model.ctc_head).cpu()}
        return snap

    def restore(self, snap):
        meta, r = snap["__meta__"], self.runner
        dev = next(r.model.parameters()).device
        r.model.intent_head = copy.deepcopy(meta["intent_head"]).to(dev)
        r.model.ctc_head = copy.deepcopy(meta["ctc_head"]).to(dev)
        r.intent_list[:] = meta["intent_list"]
        if meta["itos"] is not None:
            r.vocab.itos = list(meta["itos"])
            r.vocab.stoi = {t: i for i, t in enumerate(r.vocab.itos)}
        super().restore({k: v for k, v in snap.items() if k != "__meta__"
                         and not k.startswith(("intent_head.", "ctc_head."))})

    @staticmethod
    def _grow_linear(lin, n_new, rows_like=None):
        new = nn.Linear(lin.in_features, lin.out_features + n_new).to(lin.weight.device)
        with torch.no_grad():
            n = lin.out_features
            new.weight[:n], new.bias[:n] = lin.weight, lin.bias
            ref = list(rows_like) if rows_like else list(range(n))
            new.weight[n:] = lin.weight[ref].mean(0)
            new.bias[n:] = lin.bias[ref].mean()
        return new

    def _grow(self, intents, slot_types):
        r, msgs = self.runner, []
        new_int = [i for i in intents if i not in r.intent_list]
        if new_int:
            r.model.intent_head = self._grow_linear(r.model.intent_head, len(new_int))
            r.intent_list.extend(new_int)
            msgs.append(f"RoBISLU: added new intent(s) {', '.join(new_int)}")
        if self._char_vocab:
            new_tags = [f"<fill_{t}>" for t in slot_types if f"<fill_{t}>" not in r.vocab.stoi]
            if new_tags:
                tag_rows = [i for i, t in enumerate(r.vocab.itos) if t.startswith("<fill_")]
                r.model.ctc_head = self._grow_linear(r.model.ctc_head, len(new_tags), tag_rows)
                r.vocab.itos.extend(new_tags)
                r.vocab.stoi = {t: i for i, t in enumerate(r.vocab.itos)}
                msgs.append(f"RoBISLU: added new slot type(s) {', '.join(t[6:-1] for t in new_tags)}")
        else:
            missing = sorted({t for t in slot_types if f"<fill_{t}>" not in r.vocab.tokenizer.get_vocab()})
            if missing:
                msgs.append(f"RoBISLU (BPE vocab) cannot learn NEW slot types {missing}; intents still adapt")
        return msgs

    def prepare(self, samples):
        intents = []
        for s in samples:
            i = f"{s['scenario']}_{s['action']}"
            if i not in intents:
                intents.append(i)
        slots = []
        for s in samples:
            for t, _ in s["entities"]:
                if t not in slots:
                    slots.append(t)
        return self._grow(intents, slots)

    def loss(self, samples, ctx):
        r, vm = self.runner, self.runner.vocab_mod
        wav, att = pad_batch([s["wav"] for s in samples], ctx["device"])
        out = r.model(wav, att)
        ids = torch.tensor([r.intent_list.index(f"{s['scenario']}_{s['action']}") for s in samples],
                           device=ctx["device"])
        ce = F.cross_entropy(out["intent_logits"], ids)
        tg = [r.vocab.encode(vm.annotation_to_tagged_text(s["annotation"])) for s in samples]
        lens = torch.tensor([len(t) for t in tg], device=ctx["device"])
        flat = torch.tensor([i for t in tg for i in t], dtype=torch.long, device=ctx["device"])
        ctc = F.ctc_loss(out["ctc_log_probs"], flat, out["feat_lens"], lens,
                         blank=r.vocab.blank_id, zero_infinity=True)
        return ce + ctc

    def save(self, folder, changed_names):
        folder.mkdir(parents=True, exist_ok=True)
        r = self.runner
        state = {k: v.detach().cpu() for k, v in r.model.state_dict().items()}
        torch.save({"state_dict": state, "intent_list": list(r.intent_list),
                    "itos": list(r.vocab.itos) if self._char_vocab else None}, folder / "active.pt")
        return folder / "active.pt"

    def load(self, folder):
        f = folder / "active.pt"
        if not f.exists():
            return False
        saved = torch.load(f, map_location="cpu", weights_only=False)
        r = self.runner
        n_int = len(saved["intent_list"]) - len(r.intent_list)
        if n_int > 0:
            r.model.intent_head = self._grow_linear(r.model.intent_head, n_int)
        if saved["itos"] is not None and self._char_vocab:
            n_tok = len(saved["itos"]) - len(r.vocab.itos)
            if n_tok > 0:
                r.model.ctc_head = self._grow_linear(r.model.ctc_head, n_tok)
            r.vocab.itos = list(saved["itos"])
            r.vocab.stoi = {t: i for i, t in enumerate(r.vocab.itos)}
        r.intent_list[:] = saved["intent_list"]
        r.model.load_state_dict(saved["state_dict"])
        return True


# =========================================================================== #
# Manager: stores, adaptation loop, safety check
# =========================================================================== #
class AdaptationManager:
    def __init__(self, store_dir, device, noise_files=(), replay_dir=None, predictors=None,
                 updaters=None, tolerance=0.02, seed=0):
        """
        predictors : {model name: fn(wav np.float32) -> dict or None}   (greedy, for scoring)
        updaters   : {model name: _Updater}
        """
        self.store = Path(store_dir)
        self.device = device
        self.noise_files = list(noise_files)
        self.predictors = predictors or {}
        self.updaters = updaters or {}
        self.tolerance = tolerance
        self.sep = "| "
        self.lock = threading.Lock()
        self.rng = np.random.default_rng(seed)
        self._noise_cache = {}
        (self.store / "corrections").mkdir(parents=True, exist_ok=True)
        (self.store / "anchors").mkdir(parents=True, exist_ok=True)
        self.replay_train, self.replay_eval = self._load_replay(replay_dir)

    # ---------------------------------------------------------------- stores
    def observe_raw(self, text):
        """Learn the teacher's separator ('| ' or ', ') from a raw model output."""
        m = re.search(r"'scenario'\s*:\s*'[^']*'(\s*[,|]\s*)'action'", text or "")
        if m:
            sep = m.group(1).strip() + " "
            self.sep = sep

    def _items(self, kind):
        out = []
        for meta in sorted((self.store / kind).glob("*/meta.json")):
            try:
                d = json.loads(meta.read_text())
                d["dir"] = str(meta.parent)
                out.append(d)
            except Exception:
                continue
        return sorted(out, key=lambda d: d.get("time", 0))

    def corrections(self):
        return self._items("corrections")

    def anchors(self):
        return self._items("anchors")

    def add_anchor(self, clean, noisy, preds):
        """Remember an analysed clip with each model's current answer (pseudo label)."""
        aid = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
        d = self.store / "anchors" / aid
        d.mkdir(parents=True)
        sf.write(d / "clean.wav", clean, TARGET_SR)
        sf.write(d / "noisy.wav", noisy, TARGET_SR)
        labels = {}
        for name, p in (preds or {}).items():
            if p and p.get("scenario") and p.get("action"):
                ents = [(t, f) for t, f in sorted(sem_key(p)[1])]
                transcript = p.get("_transcript", "")
                labels[name] = {"scenario": p["scenario"], "action": p["action"], "entities": ents,
                                "annotation": build_annotation(transcript, ents) if transcript else ""}
        (d / "meta.json").write_text(json.dumps({"id": aid, "time": time.time(), "labels": labels}))
        items = self.anchors()
        for old in items[:max(0, len(items) - ANCHOR_MAX)]:
            shutil.rmtree(old["dir"], ignore_errors=True)
        return aid

    def add_correction(self, clean, noisy, scenario, action, annotation, from_anchor=None):
        sc, ac, ann, err = validate_label(scenario, action, annotation)
        if err:
            return None, err
        ents, transcript = parse_annotation(ann)
        cid = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
        d = self.store / "corrections" / cid
        d.mkdir(parents=True)
        sf.write(d / "clean.wav", clean, TARGET_SR)
        sf.write(d / "noisy.wav", noisy, TARGET_SR)
        (d / "meta.json").write_text(json.dumps({
            "id": cid, "time": time.time(), "scenario": sc, "action": ac, "annotation": ann,
            "entities": ents, "transcript": transcript}, indent=2))
        if from_anchor:   # the corrected clip must not also be kept with its wrong answer
            shutil.rmtree(self.store / "anchors" / from_anchor, ignore_errors=True)
        return cid, None

    def delete_last_correction(self):
        items = self.corrections()
        if not items:
            return None
        shutil.rmtree(items[-1]["dir"], ignore_errors=True)
        return items[-1]

    def _load_replay(self, replay_dir):
        if not replay_dir or not (Path(replay_dir) / "replay.jsonl").exists():
            return [], []
        root, rows = Path(replay_dir), []
        for line in (root / "replay.jsonl").read_text().splitlines():
            if not line.strip():
                continue
            r = json.loads(line)
            if not (root / r["audio"]).exists():
                continue
            ann = clean_annotation(r["annotation"])
            ents, transcript = parse_annotation(ann)
            rows.append({"path": str(root / r["audio"]), "scenario": r["scenario"], "action": r["action"],
                         "annotation": ann, "entities": ents, "transcript": transcript})
        rows.sort(key=lambda r: r["path"])
        rng = random.Random(1234)
        rng.shuffle(rows)
        n_eval = max(1, len(rows) // 5) if rows else 0
        return rows[n_eval:], rows[:n_eval]

    # ---------------------------------------------------------------- samples
    def _noise(self, path):
        if path not in self._noise_cache:
            self._noise_cache[path] = load_wav(path)
        return self._noise_cache[path]

    def _augment(self, clean, fallback):
        snr = AUG_SNRS[self.rng.integers(len(AUG_SNRS))]
        if snr is None or not self.noise_files:
            return fallback
        noise = self._noise(self.noise_files[self.rng.integers(len(self.noise_files))])
        return mix_snr(clean, noise, snr, self.rng)

    def _corr_samples(self):
        out = []
        for c in self.corrections():
            out.append({"clean": load_wav(Path(c["dir"]) / "clean.wav"),
                        "noisy": load_wav(Path(c["dir"]) / "noisy.wav"),
                        "scenario": c["scenario"], "action": c["action"], "annotation": c["annotation"],
                        "entities": [tuple(e) for e in c["entities"]]})
        return out

    def _old_samples(self, model_name, limit):
        """Replay (real labels) + anchors (this model's own earlier answers)."""
        out = []
        for r in self.replay_train[:limit]:
            out.append({**r, "src": "replay"})
        for a in self.anchors()[-limit:]:
            lab = a["labels"].get(model_name)
            if not lab:
                continue
            if model_name == "RoBISLU" and not lab.get("annotation"):
                continue        # needs a transcript for its CTC target
            out.append({"path": str(Path(a["dir"]) / "noisy.wav"), "clean_path": str(Path(a["dir"]) / "clean.wav"),
                        "scenario": lab["scenario"], "action": lab["action"],
                        "entities": [tuple(e) for e in lab["entities"]],
                        "annotation": lab.get("annotation") or "", "src": "anchor"})
        return out

    def _materialize(self, s, augment):
        wav = load_wav(s["path"])
        if augment:
            clean = load_wav(s["clean_path"]) if s.get("clean_path") else wav
            wav = self._augment(clean, wav)
        return {**s, "wav": wav}

    # ---------------------------------------------------------------- scoring
    def _score(self, name, items, wav_key="noisy"):
        if not items:
            return None
        pred = self.predictors[name]
        ok = 0
        for it in items:
            wav = it[wav_key] if wav_key in it else load_wav(it["path"])
            try:
                p = pred(wav)
            except Exception:
                p = None
            gold = {"scenario": it["scenario"], "action": it["action"], "entities": it["entities"]}
            ok += int(p is not None and sem_key(p) == sem_key(gold))
        return ok / len(items)

    def _eval_old(self, name, limit):
        rows = self.replay_eval[:limit]
        if rows:
            return self._score(name, rows), f"held-out replay ({len(rows)} clips)"
        anchors = [a for a in self.anchors()[-limit:] if a["labels"].get(name)]
        items = [{"path": str(Path(a["dir"]) / "noisy.wav"), **{k: a["labels"][name][k] for k in
                  ("scenario", "action")}, "entities": [tuple(e) for e in a["labels"][name]["entities"]]}
                 for a in anchors]
        return self._score(name, items), f"anchor agreement ({len(items)} clips)"

    # ---------------------------------------------------------------- adapt
    def adapt(self, names, steps=40, batch_size=4, old_per_batch=3, eval_limit=60):
        """Generator yielding progress lines. Returns per-model result rows via self.last_results."""
        corr = self._corr_samples()
        self.last_results = []
        if not corr:
            yield "No corrections saved yet."
            return
        with self.lock:
            for name in names:
                if name not in self.updaters:
                    continue
                up = self.updaters[name]
                yield f"**{name}:** scoring before the update ..."
                before_c = self._score(name, corr)
                before_o, old_what = self._eval_old(name, eval_limit)
                old_pool = self._old_samples(name, limit=500)
                snap = up.snapshot()
                notes = up.prepare(corr + old_pool)
                for p in up.module.parameters():
                    p.requires_grad_(False)
                groups = [(ps, lr) for ps, lr in up.groups() if ps]
                for ps, _ in groups:
                    for p in ps:
                        p.requires_grad_(True)
                opt = torch.optim.AdamW([{"params": ps, "lr": lr} for ps, lr in groups], weight_decay=0.0)
                up.module.eval()     # dropout off, BatchNorm statistics frozen (Conformer)
                n_corr = max(1, batch_size - (old_per_batch if old_pool else 0))
                yield (f"**{name}:** training {steps} steps on {len(corr)} correction(s)"
                       + (f" + {len(old_pool)} old examples" if old_pool else
                          " (no replay/anchor clips yet: higher risk of forgetting)") + " ...")
                ctx = {"device": self.device, "sep": self.sep}
                losses, t0 = [], time.time()
                try:
                    with torch.enable_grad():
                        for step in range(steps):
                            batch = []
                            for _ in range(n_corr):
                                c = corr[self.rng.integers(len(corr))]
                                batch.append({**c, "wav": self._augment(c["clean"], c["noisy"])})
                            if old_pool:
                                for _ in range(batch_size - n_corr):
                                    s = old_pool[self.rng.integers(len(old_pool))]
                                    batch.append(self._materialize(s, augment=self.rng.random() < 0.5))
                            loss = up.loss(batch, ctx)
                            opt.zero_grad()
                            loss.backward()
                            torch.nn.utils.clip_grad_norm_([p for ps, _ in groups for p in ps], 1.0)
                            opt.step()
                            losses.append(loss.item())
                            if (step + 1) % 10 == 0:
                                yield f"**{name}:** step {step + 1}/{steps}, loss {np.mean(losses[-10:]):.3f}"
                except Exception as e:
                    up.restore(snap)
                    self.last_results.append({"model": name, "kept": False, "reason": f"error: {e}"})
                    yield f"**{name}:** error during training ({e}); model restored."
                    continue
                finally:
                    for p in up.module.parameters():
                        p.requires_grad_(False)
                    up.module.eval()

                yield f"**{name}:** scoring after the update ..."
                after_c = self._score(name, corr)
                after_o, _ = self._eval_old(name, eval_limit)
                ok_corr = after_c > before_c or after_c == 1.0
                ok_old = before_o is None or after_o >= before_o - self.tolerance
                kept = ok_corr and ok_old
                if kept:
                    path = up.save(self.store / "models" / name, up.trainable_names())
                    hist = self.store / "models" / name / "history"
                    hist.mkdir(exist_ok=True)
                    shutil.copy(path, hist / f"{time.strftime('%Y%m%d-%H%M%S')}.pt")
                    reason = "kept"
                else:
                    up.restore(snap)
                    reason = ("rolled back: corrections not learned (try more steps or more examples)" if not ok_corr
                              else f"rolled back: old score dropped more than {self.tolerance:.0%}")
                row = {"model": name, "kept": kept, "reason": reason, "corr_before": before_c,
                       "corr_after": after_c, "old_before": before_o, "old_after": after_o,
                       "old_what": old_what, "seconds": time.time() - t0, "notes": notes}
                self.last_results.append(row)
                with open(self.store / "adapt_log.jsonl", "a") as f:
                    f.write(json.dumps(row) + "\n")
                for n in notes:
                    yield n
                yield f"**{name}:** {reason}."

    def load_active(self):
        loaded = []
        for name, up in self.updaters.items():
            try:
                if up.load(self.store / "models" / name):
                    loaded.append(name)
            except Exception as e:
                print(f"[adapt] could not load adapted {name}: {e} -> using original weights")
        return loaded

    def reset(self):
        """Move adapted weights aside (original weights are used after a restart)."""
        dst = self.store / "archive" / time.strftime("%Y%m%d-%H%M%S")
        moved = []
        for name in self.updaters:
            f = self.store / "models" / name / "active.pt"
            if f.exists():
                dst.mkdir(parents=True, exist_ok=True)
                shutil.move(str(f), dst / f"{name}.pt")
                moved.append(name)
        return moved


def results_table(rows):
    if not rows:
        return ""
    pct = lambda v: "—" if v is None else f"{v:.0%}"
    out = ["| Model | Corrections right (before → after) | Old knowledge (before → after) | Result |",
           "|---|---|---|---|"]
    for r in rows:
        if "corr_before" not in r:
            out.append(f"| {r['model']} | — | — | {r['reason']} |")
            continue
        out.append(f"| {r['model']} | {pct(r['corr_before'])} → {pct(r['corr_after'])} | "
                   f"{pct(r['old_before'])} → {pct(r['old_after'])} ({r['old_what']}) | "
                   f"{'✅ ' if r['kept'] else '↩️ '}{r['reason']} |")
    return "\n".join(out)
