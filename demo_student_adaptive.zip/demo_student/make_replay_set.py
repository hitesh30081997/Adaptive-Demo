"""
make_replay_set.py
Run ONCE on the machine that has SLURP. It copies a small, balanced sample
(N clips per intent) into one folder that you then copy to the demo machine.
During adaptation these real, labelled clips are mixed with your corrections so the
models keep their SLURP knowledge, and 20% of them are held out to check that the
old accuracy did not drop.

    python3 make_replay_set.py \
        --slurp_jsonl /path/to/slurp/dataset/slurp/train.jsonl \
        --audio_root  /path/to/slurp/audio \
        --out_dir     ./replay_set --per_intent 20

About 60 intents x 20 clips = ~1,200 clips, roughly 150-250 MB.
Then copy replay_set/ to the demo machine and set REPLAY_DIR in app_student.py.
"""
import argparse
import json
import random
import shutil
from collections import defaultdict
from pathlib import Path


def find_audio(root, fname):
    for sub in ("slurp_real", "slurp_synth", ""):
        p = Path(root) / sub / fname
        if p.exists():
            return p
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slurp_jsonl", required=True, help="SLURP train.jsonl (or devel.jsonl)")
    ap.add_argument("--audio_root", required=True, help="folder with slurp_real/ and slurp_synth/")
    ap.add_argument("--out_dir", default="./replay_set")
    ap.add_argument("--per_intent", type=int, default=20)
    ap.add_argument("--real_only", action="store_true", help="skip synthetic (TTS) recordings")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    by_intent = defaultdict(list)
    for line in open(a.slurp_jsonl):
        if not line.strip():
            continue
        r = json.loads(line)
        sc, ac = r.get("scenario"), r.get("action")
        ann = r.get("sentence_annotation") or r.get("sentence")
        if not (sc and ac and ann):
            continue
        for rec in r.get("recordings", []):
            if rec.get("file"):
                by_intent[f"{sc}_{ac}"].append((rec["file"], sc, ac, ann))

    rng = random.Random(a.seed)
    out = Path(a.out_dir)
    (out / "audio").mkdir(parents=True, exist_ok=True)
    rows, missing = [], 0
    for intent in sorted(by_intent):
        cands = by_intent[intent][:]
        rng.shuffle(cands)
        seen_sent, taken = set(), 0
        for fname, sc, ac, ann in cands:
            if taken >= a.per_intent:
                break
            if ann in seen_sent:          # prefer different sentences over repeats
                continue
            src = find_audio(a.audio_root, fname)
            if src is None or (a.real_only and "slurp_synth" in str(src)):
                missing += src is None
                continue
            shutil.copy(src, out / "audio" / src.name)
            rows.append({"audio": f"audio/{src.name}", "scenario": sc, "action": ac, "annotation": ann})
            seen_sent.add(ann)
            taken += 1

    with open(out / "replay.jsonl", "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    print(f"Wrote {len(rows)} clips for {len(by_intent)} intents to {out} ({missing} audio files not found)")


if __name__ == "__main__":
    main()
